/**
 * Provides the business services and factory interfaces for the Bank system.
 *
 * NOTE: Its not allowed to edit or add anything in this package.
 */
@Sealed
package com.unibet.worktest.bank;